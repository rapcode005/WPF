using Microsoft.VisualStudio.TestTools.UnitTesting;
using demo.ViewModel;
using ServiceReference1;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WPFTesting
{
    [TestClass]
    public class PersonTests
    {
        private PersonViewModel ViewModel;

        public PersonTests()
        {
            ViewModel = new PersonViewModel();
        }

        [TestMethod]
        public async void GetPerson()
        {
            var actualFeedData = await ViewModel.GetAllPerson();

            int cnt = actualFeedData.Count;

            Assert.IsTrue(cnt == 17);
        }

        [TestMethod]
        public async Task AddPerson()
        {
            PersonDto newPerson = new PersonDto()
            {
                FirstName="keito",
                LastName="Kemmochi",
                Age=11
            };

            var actualFeedData = await ViewModel.AddPerson(newPerson);

            var expected = new PersonDto() { Id = 34 };

            Assert.IsNotNull(actualFeedData);
            Assert.AreNotEqual(actualFeedData, expected.Id);
        }
    }
}
