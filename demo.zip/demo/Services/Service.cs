﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace demo.Services
{
    public class Service : IService
    {
        public bool ValidationAge(int num, out ICollection<string> 
            ValidationErrors, string PropetyName)
        {
            ValidationErrors = new List<string>();

            if (num <= 0)
                ValidationErrors.Add(PropetyName
                    + " is invalid input.");

            return ValidationErrors.Count == 0;
        }

        public bool ValidationString(string str,
            out ICollection<string> ValidationErrors,
            string PropetyName)
        {
            ValidationErrors = new List<string>();

            if (string.IsNullOrEmpty(str))
                ValidationErrors.Add(PropetyName + " is required.");

            //if (!Regex.IsMatch(FirstName, @"^[a-zA-Z]+$"))
              //  ValidationErrors.Add("The FirstName must only contain letters (a-z, A-Z).");

            return ValidationErrors.Count == 0;
        }
    }
}
