﻿using System.Collections.Generic;

namespace demo.Services
{
    public interface IService
    {
        bool ValidationString(string FirstName, 
            out ICollection<string> ValidationErrors,
            string PropetyName);

        bool ValidationAge(int num,
             out ICollection<string> ValidationErrors,
            string PropetyName);
    }
}