﻿namespace demo.Model
{
    public interface IApiData
    {
        string ID { get; set; }
        string Name { get; set; }
    }
}