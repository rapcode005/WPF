﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo.Model
{
    public class ApiData : IApiData
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
}
