﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using demo.Abstract;

namespace demo.Model
{
    public class Person : Notify, IPerson
    {
        private int _id;
        private string _firstName;
        private string _lastName;
        private int _age;
        private string _data;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertyChanged("FirstName");
            }
        }

        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertyChanged("LastName");
            }
        }

        public int Age
        {
            get { return _age; }
            set
            {
                _age = value;
                OnPropertyChanged("Age");
            }
        }

        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
            }
        }

        public string Data
        {
            get { return _data; }
            set
            {
                _data = value;
                OnPropertyChanged("Data");
            }
        }

    }
}
