﻿using ServiceReference1;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
    public class Head
    {
        public PersonList curSel;
        public string searchText;
        public string searchType;
        public bool IsAsc;

        public virtual async Task<ObservableCollection<PersonDto>> Searching()
        {
            return new ObservableCollection<PersonDto>();
        }

        public virtual async Task<ObservableCollection<PersonDto>> Sorting()
        {
            return new ObservableCollection<PersonDto>();
        }
    }
}
