﻿using demo.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
    public class PersonList : ObservableCollection<Person>
    {
        public PersonList() : base()
        {
            /*
            Add(new Person { Id = 1, FirstName = "Raj", LastName = "Beniwal", Age = 30 });
            Add(new Person { Id = 2, FirstName = "Rap", LastName = "Paul", Age = 20 });
            Add(new Person { Id = 3, FirstName = "Rain", LastName = "Zap", Age = 16 });
            Add(new Person { Id = 4, FirstName = "Rose", LastName = "Paul", Age = 35 });
            Add(new Person { Id = 5, FirstName = "Apple", LastName = "Lemon", Age = 51 });*/
        }
    }
}
