﻿using System;
using System.Collections.Generic;
using System.Text;

namespace demo.Abstract
{
    public interface IClosable
    {
        void Execute();
    }

}
