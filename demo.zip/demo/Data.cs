﻿using demo.Model;
using ServiceReference1;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
    public class Data: Head
    {
        public override async Task<ObservableCollection<PersonDto>> Searching()
        {
            PersonServicesClient personClient = new PersonServicesClient();
            searchText = "%" + searchText + "%";
            searchType = "Data Like ";
            var pd = await personClient.SearchPersonDataAsync(
                searchText,
                searchType);
            return new ObservableCollection<PersonDto>(pd);
            /*foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
            }*/
        }

        public override async Task<ObservableCollection<PersonDto>> Sorting()
        {
            PersonServicesClient personClient = new PersonServicesClient();
            if (!string.IsNullOrEmpty(searchText) && !string.IsNullOrEmpty(searchType))
            {
                searchType = searchType.Replace(" ", "");
                if (searchType == "LastName" || searchType == "FirstName" || searchType=="Data")
                {
                    searchText = "%" + searchText + "%";
                    searchType = searchType + " Like ";
                }
                else
                {
                    searchType = searchType + " =";
                }
            }
            var pd = await personClient.SortPersonDataAsync(IsAsc, "Data",
                searchText,
                searchType);
            return new ObservableCollection<PersonDto>(pd);
            /*foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
            }*/
        }
    
    }
}
