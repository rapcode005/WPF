﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using ServiceReference1;
using System.Collections.ObjectModel;

namespace demo
{
    public class Age : Head
    {
        public override async Task<ObservableCollection<PersonDto>> Searching()
        {
            PersonServicesClient personClient = new PersonServicesClient();
            searchType = (string.IsNullOrEmpty(searchText)) ? "Age Like" : "Age = ";
            searchText = (string.IsNullOrEmpty(searchText)) ? "%%" : searchText;
            var pd = await personClient.SearchPersonDataAsync(searchText, searchType);
            return new ObservableCollection<PersonDto>(pd);
           /* foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
            }*/
        }

        public override async Task<ObservableCollection<PersonDto>> Sorting()
        {
            //PersonList Persons = new PersonList();
            PersonServicesClient personClient = new PersonServicesClient();
            if (!string.IsNullOrEmpty(searchText) && !string.IsNullOrEmpty(searchType))
            {
                searchType = searchType.Replace(" ", "");
                if (searchType == "LastName" || searchType == "FirstName" || searchType == "Data")
                {
                    searchText = "%" + searchText + "%";
                    searchType = searchType + " Like ";
                }
                else
                {
                    searchType = searchType + " =";
                }
            }
            var pd = await personClient.SortPersonDataAsync(IsAsc, "Age", searchText, searchType);
            return new ObservableCollection<PersonDto>(pd);
            /*foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
            }*/
        }
    }
}
