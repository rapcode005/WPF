﻿using demo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace demo.Command
{
    public class RelayCommand<TParameter> : ICommand
    {
        readonly Action<TParameter> _execteMethod;
        readonly Func<TParameter, bool> _canexecuteMethod;

        //public Action<Person> Sort { get; }
        //public Func<object, bool> P { get; }

        public RelayCommand(Action<TParameter> execteMethod, Func<TParameter, bool> canexecuteMethod)
        {
            _execteMethod = execteMethod;
            _canexecuteMethod = canexecuteMethod;
        }

        /*public RelayCommand(Action<Person> sort, Func<object, bool> p)
        {
            Sort = sort;
            P = p;
        }*/

        public bool CanExecute(object parameter)
        {
            if (this._execteMethod == null) return true;

            return this._canexecuteMethod((TParameter)parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            this._execteMethod((TParameter)parameter);
        }
    }
}
