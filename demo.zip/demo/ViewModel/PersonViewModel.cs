﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Linq;
//using DomainModel;
using demo.Command;
using System.Windows;
using demo.Abstract;
using demo.View;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Globalization;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Data;
using ServiceReference1;
using demo.Model;
using demo.Services;

namespace demo.ViewModel
{

    /*public class JsonFile
    {
        public object[] businessPhones { get; set; }
        public string displayName { get; set; }
        public string jobTitle { get; set; }
        public string mail { get; set; }
        public string mobilePhone { get; set; }
        public string officeLocation { get; set; }
        public string givenName { get; set; }
        public string surname { get; set; }
        public string userPrincipalName { get; set; }
        public string id { get; set; }
    }*/

    public class PersonViewModel : Notify
    {
        private Dictionary<string, Type> dict = new Dictionary<string, Type>();
        private string m_ContentButton = "Edit", m_search, m_searchType = "First Name";
        private bool m_isReadOnly = true, m_include = false, m_isInclude;
        private PersonDto m_item;
        private string m_dataItem;
        private ObservableCollection<PersonDto> m_currentList;
        private ObservableCollection<ApiData> m_data;
        private bool IsAsc = false;
        public UpdatePersonWindow UpdateWindow = new UpdatePersonWindow();
        private UpdateViewModel UpdateViewModel = new UpdateViewModel(new Service());
        public ICommand CreateCommand { get; private set; }
        public ICommand UpdateCommand { get; private set; }
        public ICommand DeleteCommand { get; private set; }
        public ICommand SearchCommand { get; private set; }
        public ICommand SortCommand { get; private set; }
        public ICommand SearchTypeCommand { get; private set; }
        public bool IsReadOnly {
            get
            {
                return m_isReadOnly;
            }
            set
            {
                m_isReadOnly = value;
                IsInclude = !m_isReadOnly;
                OnPropertyChanged("IsReadOnly");
            }
        }
        public bool IsInclude
        {
            get
            {
                return m_isInclude;
            }
            set
            {
                m_isInclude = value;
                OnPropertyChanged("IsInclude");
            }
        }
        public string ContentButton
        {
            get
            {
                return m_ContentButton;
            }
            set
            {
                m_ContentButton = value;
                OnPropertyChanged("ContentButton");
            }
        }
        public string SearchText
        {
            get
            {
                return m_search;
            }
            set
            {
                m_search = value;
                OnPropertyChanged("SearchText");
            }
        }
        public PersonDto Item
        {
            get
            {
                return m_item;
            }
            set
            {
                m_item = value;
                OnPropertyChanged("Item");

                if(!(Item is null))
                {
                    UpdateViewModel.FirstName = Item.FirstName;
                    UpdateViewModel.LastName = Item.LastName;
                    UpdateViewModel.Age = Item.Age;
                    UpdateViewModel.Id = Item.Id;
                    UpdateViewModel.Id = Item.Id;
                    UpdateViewModel.CurrentData = Item.Data;
                    UpdateViewModel.Copy = this;

                    UpdateWindow.DataContext = UpdateViewModel;
                    
                    UpdateWindow.Owner = Application.Current.MainWindow;
                    if(UpdateWindow.Visibility == Visibility.Hidden ||
                        UpdateWindow.Visibility == Visibility.Collapsed)
                    {
                        UpdateWindow.Show();
                    }
                }
            }
        }
        private string GetNameFromValue(string ID)
        {
            foreach (var tom in Data.Where(i => i.ID == ID))
            {
                return tom.Name;
            }
            return "";
        }
        public string SearchType
        {
            get
            {
                return m_searchType;
            }
            set
            {
                m_searchType = value;
                OnPropertyChanged("SearchType");
            }
        }
        public PersonViewModel()
        {
            //Persons = new ObservableCollection<PersonData>();
            DataLoad();

            SampleAPI();

            CreateCommand = new RelayCommand<Object>(ExecuteAsync, CanExecute);
            UpdateCommand = new RelayCommand<Object>(ExecuteUpdate, CanExecuteUpdate);
            DeleteCommand = new RelayCommand<Object>(Delete, o => true);
            SearchCommand = new RelayCommand<string>(Search, o => true);
            SortCommand = new RelayCommand<string>(Sort, o => true);
            SearchTypeCommand = new RelayCommand<string>((parameter) =>
            {
                SearchType = parameter;
            }, o => true);
 
            dict.Add("First Name", typeof(FirstName));
            dict.Add("Last Name", typeof(LastName));
            dict.Add("Age", typeof(Age));
            dict.Add("ID", typeof(ID));
            dict.Add("Data", typeof(Data));

            UpdateViewModel.IsOpen = false;
        }

        private void SampleAPI()
        {
            WebRequest web = WebRequest.Create("https://graph.microsoft.com/v1.0/me");
            web.Method = "GET";
            web.Headers.Add("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6IlRXYzE0cVNJYXFBY3hycUU0aWJWV0VlamtVSzF2X0ZKMzBkdFlaaFd2SHciLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9lMDc5M2QzOS0wOTM5LTQ5NmQtYjEyOS0xOThlZGQ5MTZmZWIvIiwiaWF0IjoxNjIyNjE2NDA4LCJuYmYiOjE2MjI2MTY0MDgsImV4cCI6MTYyMjYyMDMwOCwiYWNjdCI6MCwiYWNyIjoiMSIsImFjcnMiOlsidXJuOnVzZXI6cmVnaXN0ZXJzZWN1cml0eWluZm8iLCJ1cm46bWljcm9zb2Z0OnJlcTEiLCJ1cm46bWljcm9zb2Z0OnJlcTIiLCJ1cm46bWljcm9zb2Z0OnJlcTMiLCJjMSIsImMyIiwiYzMiLCJjNCIsImM1IiwiYzYiLCJjNyIsImM4IiwiYzkiLCJjMTAiLCJjMTEiLCJjMTIiLCJjMTMiLCJjMTQiLCJjMTUiLCJjMTYiLCJjMTciLCJjMTgiLCJjMTkiLCJjMjAiLCJjMjEiLCJjMjIiLCJjMjMiLCJjMjQiLCJjMjUiXSwiYWlvIjoiQVZRQXEvOFRBQUFBRjdTMm1NTzdIa3dPOWd5QjhWZlVyS3FVWGJ4ZDBMSzI3Ui9ITzFWSEhCcEdPT1ZreGM4MFQrZm5oUWNtNURmZ3lvZzVQbEVjZWVlV2ZKUnE1RXBKdlBIbmdRSE9mOUt5QTE3Q09IK1l3S1k9IiwiYW1yIjpbIndpYSIsIm1mYSJdLCJhcHBfZGlzcGxheW5hbWUiOiJHcmFwaCBleHBsb3JlciAob2ZmaWNpYWwgc2l0ZSkiLCJhcHBpZCI6ImRlOGJjOGI1LWQ5ZjktNDhiMS1hOGFkLWI3NDhkYTcyNTA2NCIsImFwcGlkYWNyIjoiMCIsImNvbnRyb2xzIjpbImFwcF9yZXMiXSwiY29udHJvbHNfYXVkcyI6WyIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCIwMDAwMDAwMy0wMDAwLTBmZjEtY2UwMC0wMDAwMDAwMDAwMDAiXSwiZGV2aWNlaWQiOiI4MTc5NWQ1NS01ZTc0LTQ2MDUtYTgzZS04MWVlYWQ1NGNlMjEiLCJmYW1pbHlfbmFtZSI6Ik9uZyIsImdpdmVuX25hbWUiOiJSYWZhZWwiLCJpZHR5cCI6InVzZXIiLCJpbl9jb3JwIjoidHJ1ZSIsImlwYWRkciI6IjEzNi4xNTguMzAuMTc2IiwibmFtZSI6Ik9uZyBJSUksIFJhZmFlbCIsIm9pZCI6ImM3NTAzMjE3LThiYzItNGUwOS1hMjJhLTQ1MzFkY2NhYWE0MiIsIm9ucHJlbV9zaWQiOiJTLTEtNS0yMS0zMjkwNjgxNTItMTQ1NDQ3MTE2NS0xNDE3MDAxMzMzLTEwNTYzNjE2IiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAxMjk4NUFBNTUiLCJyaCI6IjAuQVhzQU9UMTU0RGtKYlVteEtSbU8zWkZ2NjdYSWk5NzUyYkZJcUsyM1NOcHlVR1I3QVBRLiIsInNjcCI6IkFwcGxpY2F0aW9uLlJlYWQuQWxsIEF1ZGl0TG9nLlJlYWQuQWxsIENhbGVuZGFycy5SZWFkV3JpdGUgQ29udGFjdHMuUmVhZFdyaXRlIERpcmVjdG9yeS5BY2Nlc3NBc1VzZXIuQWxsIERpcmVjdG9yeS5SZWFkV3JpdGUuQWxsIEZpbGVzLlJlYWRXcml0ZS5BbGwgR3JvdXAuUmVhZFdyaXRlLkFsbCBJZGVudGl0eVJpc2tFdmVudC5SZWFkLkFsbCBNYWlsLlJlYWRXcml0ZSBNZW1iZXIuUmVhZC5IaWRkZW4gTm90ZXMuUmVhZFdyaXRlLkFsbCBvcGVuaWQgUGVvcGxlLlJlYWQgUG9saWN5LlJlYWRXcml0ZS5Db25kaXRpb25hbEFjY2VzcyBwcm9maWxlIFNpdGVzLlJlYWRXcml0ZS5BbGwgVGFza3MuUmVhZFdyaXRlIFVzZXIuUmVhZCBVc2VyLlJlYWQuQWxsIFVzZXIuUmVhZEJhc2ljLkFsbCBVc2VyLlJlYWRXcml0ZSBVc2VyLlJlYWRXcml0ZS5BbGwgZW1haWwiLCJzaWduaW5fc3RhdGUiOlsiZHZjX21uZ2QiLCJkdmNfZG1qZCIsImttc2kiXSwic3ViIjoidTNENEIwbmUwNUJuYy1MZ296dVVSQ25hZFJDZW4wSHR2NWtzNDF5UzA2ZyIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJXVyIsInRpZCI6ImUwNzkzZDM5LTA5MzktNDk2ZC1iMTI5LTE5OGVkZDkxNmZlYiIsInVuaXF1ZV9uYW1lIjoicmFmYWVsLm9uZ0BhY2NlbnR1cmUuY29tIiwidXBuIjoicmFmYWVsLm9uZ0BhY2NlbnR1cmUuY29tIiwidXRpIjoiZ05kMWNCb2dCRW0zbFVZLWdGY0JBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il0sInhtc19zdCI6eyJzdWIiOiJ0Q3E2TzVSc0EtblJqSWFhVVRJM0s1MVdnNWZoWGNzMTJqSFBzaU5CQmgwIn0sInhtc190Y2R0IjoxMzk2MDQ5MzY0fQ.ZavNiWzBiLOgo-LGgQf1pD-A_9qQ5oywalEs7Y8-0_URxohG1HoyfpEiH2nabOrI3FBHsFHp_WWx7aSqPSQNtbgzfQ7xLO-SmOM5i7H3AQeAPFLLg3ytd56I1XZk6MQ9hRWcmAQGWz4z-bKcasPGagfaP0MHsH3g_U2fYiWsBbMtIKR_Tcr5irCk-kQ5xxDtwdpO91o3sS22EcN5zSbEugMi0OZQ67hDcevMEVRKPuViQ00riSNeml6tmJQQpSOAPDElFZAEP19uHci3BZ9RbuYveaVHDtHDMci9PQg2yzD7z9ABjbPhDdDM3mpMXScCuky38IHew-xtDM5tMkyWTQ");
            WebResponse res = web.GetResponse();

            Data = new ObservableCollection<ApiData>();

            using (Stream dataStream = res.GetResponseStream())
            {
                StreamReader reader = new StreamReader(dataStream, Encoding.UTF8);
                string responseFromServer = reader.ReadLine();
                //Convert Json string to Object
                var result = JsonSerializer.Deserialize<JsonAPI>(responseFromServer);
                Data.Add(new ApiData
                {
                    Name = "",
                    ID = "None"
                });
                Data.Add(new ApiData
                {
                    Name = result.displayName,
                    ID = nameof(result.displayName)
                });
                Data.Add(new ApiData
                {
                    Name = result.jobTitle,
                    ID = nameof(result.jobTitle)
                });
                Data.Add(new ApiData
                {
                    Name = result.userPrincipalName,
                    ID = nameof(result.userPrincipalName)
                });
                Data.Add(new ApiData
                {
                    Name = result.givenName,
                    ID = nameof(result.givenName)
                });
                Data.Add(new ApiData
                {
                    Name = result.surname,
                    ID = nameof(result.surname)
                });
                Data.Add(new ApiData
                {
                    Name = result.officeLocation,
                    ID = nameof(result.officeLocation)
                });
            }

            res.Close();

            UpdateViewModel.Data = Data;

        }

        public async Task<List<PersonDto>> GetAllPerson()
        {
            PersonServicesClient personServicesClient = new PersonServicesClient();
            PersonDto[] r = await personServicesClient.GetPersonDataAsync();
            return r.ToList();
        }

        private async void DataLoad()
        {
            List<PersonDto> r = await GetAllPerson();
            Persons = new ObservableCollection<PersonDto>(r);
        }


        private async void Sort(string parameter)
        {
            Head obj = (Head)(Activator.CreateInstance(dict[parameter]));
            obj.IsAsc = IsAsc;
            obj.searchText = SearchText;
            obj.searchType = SearchType;
            Persons = await obj.Sorting();
            IsAsc = !IsAsc;
        }

        private async void Search(string parameter)
        {
            Head obj = (Head)(Activator.CreateInstance(dict[SearchType]));
            obj.searchText = SearchText;
            obj.searchType = SearchType;
            Persons = await obj.Searching();
        }

        private async void DeletePerson(int id)
        {
            PersonServicesClient personClient = new PersonServicesClient();
            _ = await personClient.DeletePersonDataAsync(id);
        }

        private void Delete(object parameter)
        {
            DeletePerson(Item.Id);
            Persons.Remove(Item);
            if (UpdateWindow.Visibility == Visibility.Visible)
            {
                UpdateWindow.Hide();
            }
        }

        private bool CanExecute(object parameter)
        {
            return true;
        }

        public async Task<int> AddPerson(PersonDto data)
        {
            PersonServicesClient personServiceClient = new PersonServicesClient();
            var r = await personServiceClient.AddPersonDataAsync(data);
            return r.Id;
        }

        private async void ExecuteAsync(object parameter)
        {
            IService s = new Service();
            CreateWindow window = new CreateWindow
            {
                DataContext = new CreateViewModel(s)
            };
            _ = window.ShowDialog();
            var vm = (CreateViewModel)window.DataContext;
            if (vm.IsSave)
            {
                int NewID = await AddPerson(new PersonDto
                {
                    Age = vm.Age,
                    FirstName = vm.FirstName,
                    LastName = vm.LastName
                    //Id = Persons.Count + 1
                });
                Persons.Add(new PersonDto
                {
                    FirstName = vm.FirstName,
                    LastName = vm.LastName,
                    Age = vm.Age,
                    Id = NewID
                });
                OnPropertyChanged("Persons");

                MessageBox.Show("Successfully Added!", "New Person");
            }
        }


        private bool CanExecuteUpdate(object parameter)
        {
            return true;
        }

        private async void UpdatePerson(PersonDto data)
        {
            PersonServicesClient PersonServiceClient = new PersonServicesClient();
            var r = await PersonServiceClient.UpdatePersonDataAsync(data);
        }
        private void ExecuteUpdate(object parameter)
        {
            IsReadOnly = !IsReadOnly;
            if (IsReadOnly)
            {
                string NameData = GetNameFromValue(SelectData);
                UpdatePerson(new PersonDto
                {
                    Age = Item.Age,
                    Id = Item.Id,
                    FirstName = Item.FirstName,
                    LastName = Item.LastName,
                    Data = NameData
                });
                foreach (var tom in Persons.Where(w => w.Id == Item.Id))
                {
                    tom.FirstName = Item.FirstName;
                    tom.LastName = Item.LastName;
                    tom.Age = Item.Age;
                    tom.Data = NameData;
                }
                ContentButton = "Edit";
                MessageBox.Show("Successfully Updated!", "Person");
            }
            else
            {
                ContentButton = "Done";
            }
        }

        public ObservableCollection<PersonDto> Persons
        { 
            get
            {
                return m_currentList;
            }
            set
            {
                m_currentList = value;
                OnPropertyChanged("Persons");
            }
        }

        public ObservableCollection<ApiData> Data
        {
            get
            {
                return m_data;
            }
            set
            {
                m_data = value;
                OnPropertyChanged("Data");
            }
        }


        public string SelectData
        {
            get
            {
                return m_dataItem;
            }
            set
            {
                m_dataItem = value;
                OnPropertyChanged("SelectData");
            }
        }

        public bool Include
        {
            get
            {
                return m_include;
            }
            set
            {
                if (m_include != value)
                {
                    m_include = value;
                    OnPropertyChanged("Include");
                }
            }
        }

    }
}
