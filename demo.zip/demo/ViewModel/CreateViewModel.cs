﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using demo.Abstract;
using demo.Command;
using demo.Model;
using demo.Services;

namespace demo.ViewModel
{
    class CreateViewModel : Notify, IPerson, INotifyDataErrorInfo
    {
        private bool m_isSave = false;
        private string m_firstName, m_lastName;
        private Brush m_backgroundColor = Brushes.DarkGray;
        private int m_age;

        public Brush BackgroundColor
        {
            get
            {
                return m_backgroundColor;
            }
            set
            {
                m_backgroundColor = value;
                OnPropertyChanged("BackgroundColor");
            }
        }
        public bool IsSave
        {
            get
            {
                return m_isSave;
            }
            set
            {
                m_isSave = value;
                OnPropertyChanged("IsSave");
            }
        }
        public string FirstName {
            get
            {
                return m_firstName;
            }
            set
            {
                m_firstName = value;
                ValidateStr(m_firstName, "First Name", typeof(FirstName).Name);
                OnPropertyChanged("FirstName");
            }
        }
        public string LastName
        {
            get
            {
                return m_lastName;
            }
            set
            {
                m_lastName = value;
                ValidateStr(m_lastName, "Last Name", typeof(LastName).Name);
                OnPropertyChanged("LastName");
            }
        }
        public int Age
        {
            get
            {
                return m_age;
            }
            set
            {
                m_age = value;
                ValidateNumberNoNeg(m_age, "Age", typeof(Age).Name);
                OnPropertyChanged("Age");
            }
        }
        public RelayCommand<Window> SaveCommand { get; set; }
        public int Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string Data { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }


        private readonly IService _service;
        private readonly Dictionary<string, ICollection<string>>
            _validationErrors = new Dictionary<string, ICollection<string>>();


        public CreateViewModel(IService service)
        {
            SaveCommand = new RelayCommand<Window>(async (window) => {
                bool first = await ValidateString(FirstName, "First Name", typeof(FirstName).Name);
                bool last = await ValidateString(LastName, "Last Name", typeof(LastName).Name);
                bool age = await ValidateNumberNoNegative(Age, "Age", typeof(Age).Name);
                if (first && last && age && window != null)
                {
                    IsSave = true;
                    window.Close();
                }
            }, o => true);

            _service = service;
        }

        #region INotifyDataErrorInfo members
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;
        public IEnumerable GetErrors(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName)
            || !_validationErrors.ContainsKey(propertyName))
                return null;

            return _validationErrors[propertyName];
        }

        private void RaiseErrorsChanged(string propertyName)
        {
            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        public bool HasErrors
        {
            get { return _validationErrors.Count > 0; }
        }
        #endregion

        #region Validation
        public async void ValidateStr(string str, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationString(str, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
        }

        private async Task<bool> ValidateString(string str, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationString(str, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else
                return true;
        }
        
        public async void ValidateNumberNoNeg(int num, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationAge(num, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
        }
        public async Task<bool> ValidateNumberNoNegative(int num, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationAge(num, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else
                return true;
        }
        #endregion

    }
}
