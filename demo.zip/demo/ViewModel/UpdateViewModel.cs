﻿using demo.Abstract;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using demo.Command;
using System.Windows.Input;
using System.Linq;
using ServiceReference1;
using System.Windows;
using demo.Model;
using System.ComponentModel;
using demo.Services;
using System.Collections;
using System.Threading.Tasks;

namespace demo.ViewModel
{
    class UpdateViewModel: Notify, INotifyDataErrorInfo
    {
        private string m_firstName, m_lastName, m_dataItem, 
            m_currentData;
        private int m_age, m_id;
        private bool m_include,m_open;
        private ObservableCollection<ApiData> m_data;
        private PersonViewModel m_copy;
        private readonly IService _service;
        private readonly Dictionary<string, ICollection<string>>
            _validationErrors = new Dictionary<string, ICollection<string>>();

        public bool IsOpen
        {
            get => m_open;
            set
            {
                m_open = value;
                OnPropertyChanged("IsOpen");
            }
        }

        public  ICommand UpdateCommand { get; set; }
        public ICommand CloseCommand { get; set; }

        private string GetNameFromValue(string ID)
        {
            foreach (var tom in Data.Where(i => i.ID == ID))
            {
                return tom.Name;
            }
            return "";
        }

        public UpdateViewModel(IService service)
        {
            _service = service;
            UpdateCommand = new RelayCommand<Window>(async (parameter) =>
            {
                
                bool first = await ValidateString(FirstName, "First Name",
                    nameof(FirstName));
                bool Last = await ValidateString(LastName, "Last Name",
                 nameof(LastName));
                bool age = await ValidateNumberNoNegative(Age, "Age",
                 nameof(Age));

                if (first && Last && age)
                {
                    string NameData = GetNameFromValue(SelectData);
                    UpdatePerson(new PersonDto
                    {
                        Age = Age,
                        Id = Id,
                        FirstName = FirstName,
                        LastName = LastName,
                        Data = NameData
                    });

                    int ind = -1;
                    PersonDto p = new PersonDto();
                    p.Age = Age;
                    p.Data = NameData;
                    p.FirstName = FirstName;
                    p.LastName = LastName;
                    p.Id = Id;

                    foreach (var tom in Copy.Persons
                    .Where(i => i.Id == Id))
                    {
                        ind = Copy.Persons.IndexOf(tom);
                    }
                    
                    if(ind >= 0) { 
                        //Remove from List
                        Copy.Persons.RemoveAt(ind);

                        //Add Update data to the list
                        Copy.Persons.Insert(ind, p);
                    }

                    Copy.UpdateWindow.Hide();
                }

            }, o => true);

            CloseCommand = new RelayCommand<Window>((parameter) =>
            {
                Copy.UpdateWindow.Hide();
            },
            o => true);
        }

        private async void UpdatePerson(PersonDto data)
        {
            PersonServicesClient PersonServiceClient = new PersonServicesClient();
            var r = await PersonServiceClient.UpdatePersonDataAsync(data);
        }

        public ObservableCollection<ApiData> Data
        {
            get
            {
                return m_data;
            }
            set
            {
                m_data = value;
                OnPropertyChanged("Data");
            }
        }

        public string FirstName
        {
            get => m_firstName;
            set
            {
                m_firstName = value;
                ValidateStr(m_firstName, "First Name", typeof(FirstName).Name);
                OnPropertyChanged("FirstName");
            }
        }
        public string LastName 
        {
            get => m_lastName;
            set 
            {
                m_lastName = value;
                ValidateStr(m_lastName, "Last Name", typeof(LastName).Name);
                OnPropertyChanged("LastName");
            }
        }
        public int Id 
        { 
            get => m_id; 
            set
            {
                m_id = value;
                OnPropertyChanged("Id");
            }
        }
        public int Age 
        { 
            get => m_age; 
            set
            {
                m_age = value;
                ValidateNumberNoNeg(m_age, "Age", typeof(Age).Name);
                OnPropertyChanged("Age");
            }
        }

        public bool Include
        {
            get
            {
                return m_include;
            }
            set
            {
                if (m_include != value)
                {
                    m_include = value;
                    OnPropertyChanged("Include");
                }
            }
        }

        public string SelectData
        {
            get
            {
                return m_dataItem;
            }
            set
            {
                m_dataItem = value;
                OnPropertyChanged("SelectData");
                if (value == "None")
                    Include = false;
                else
                    Include = true;
            }
        }

        public PersonViewModel Copy
        {
            get
            {
                return m_copy;
            }
            set
            {
                m_copy = value;
                OnPropertyChanged("Copy");
            }
        }

        public string CurrentData
        {
            get
            {
                return m_currentData;
            }
            set
            {
                m_currentData = value;
                OnPropertyChanged("CurrentData");

                SelectData = "None";

                foreach (var tom in Data.Where(i => i.Name == CurrentData))
                {
                    SelectData = tom.ID;
                }
            }
        }

        #region INotifyDataErrorInfo members
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;
        public IEnumerable GetErrors(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName)
            || !_validationErrors.ContainsKey(propertyName))
                return null;

            return _validationErrors[propertyName];
        }

        private void RaiseErrorsChanged(string propertyName)
        {
            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        public bool HasErrors
        {
            get { return _validationErrors.Count > 0; }
        }
        #endregion

        #region Validation
        public async void ValidateStr(string str, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationString(str, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
        }

        private async Task<bool> ValidateString(string str, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationString(str, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else
                return true;
        }

        public async void ValidateNumberNoNeg(int num, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationAge(num, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
            }
        }
        public async Task<bool> ValidateNumberNoNegative(int num, string Header,
            string propertyKey)
        {
            //const string propertyKey = "FirstName";
            ICollection<string> validationErrors = null;
            /* Call service asynchronously */
            bool isValid = await Task.Run(() =>
            {
                return _service.ValidationAge(num, out validationErrors,
                    Header);
            })
            .ConfigureAwait(false);

            if (!isValid)
            {
                /* Update the collection in the dictionary returned by the GetErrors method */
                _validationErrors[propertyKey] = validationErrors;
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else if (_validationErrors.ContainsKey(propertyKey))
            {
                /* Remove all errors for this property */
                _validationErrors.Remove(propertyKey);
                /* Raise event to tell WPF to execute the GetErrors method */
                RaiseErrorsChanged(propertyKey);
                return false;
            }
            else
                return true;
        }
        #endregion
    }
}
