﻿using demo.Model;
using demo.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceReference1;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace demo
{
    public class FirstName : Head
    {
 
        public override async Task<ObservableCollection<PersonDto>> Searching()
        {
            PersonServicesClient personClient = new PersonServicesClient();
            searchText = "%" + searchText + "%";
            searchType = "FirstName Like ";
            var pd = await personClient.SearchPersonDataAsync(
                searchText, 
                searchType);
            return new ObservableCollection<PersonDto>(pd);
            /*foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
            }*/
        }

        public override async Task<ObservableCollection<PersonDto>> Sorting()
        {
            PersonServicesClient personClient = new PersonServicesClient();
            if (!string.IsNullOrEmpty(searchText) && !string.IsNullOrEmpty(searchType))
            {
                searchType = searchType.Replace(" ", "");
                if(searchType == "LastName" || searchType == "FirstName" || searchType == "Data")
                {
                    searchText = "%" + searchText + "%";
                    searchType = searchType + " Like ";
                }
                else
                {
                    searchType = searchType + " =";
                }
            }
            var pd = await personClient.SortPersonDataAsync(IsAsc, "FirstName", 
                searchText, 
                searchType);
           return new ObservableCollection<PersonDto>(pd);
            /*foreach (PersonData pds in pd)
            {
                Persons.Add(new Person
                {
                    Age = pds.Age,
                    FirstName = pds.FirstName,
                    LastName = pds.LastName,
                    Id = pds.Id,
                    Data = pds.Data
                });
        }*
            /*
            if (IsAsc)
            {
                var result = from p in curSel
                             orderby p.FirstName
                             select p;

                Persons.Clear();
                foreach (Person i in result.ToList())
                    Persons.Add(i);
            }
            else
            {
                var result = from p in curSel
                             orderby p.FirstName descending
                             select p;

                Persons.Clear();
                foreach (Person i in result.ToList())
                    Persons.Add(i);
            }*/
        }

    }
}
