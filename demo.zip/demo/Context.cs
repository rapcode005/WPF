﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace demo
{
    //ContextMenu for Listview
    public class Context : Freezable
    {
        protected override Freezable CreateInstanceCore()
        {
            return new Context();
        }

        public object Data
        {
            get { return (object)GetValue(DataProperty); }
            set { SetValue(DataProperty, value); }
        }

        public static readonly DependencyProperty DataProperty =
            DependencyProperty.Register("Data", typeof(object), typeof(Context), new UIPropertyMetadata(null));
    }
}
